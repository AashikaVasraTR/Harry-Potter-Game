/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package world_of_harry_potter_reveal_and_dual;

/**
 *
 * @author Magical Me
 */
public interface EnemyFactoryIF {
   public EnemySelectionInterface buildEnemyObject(String name);
}
