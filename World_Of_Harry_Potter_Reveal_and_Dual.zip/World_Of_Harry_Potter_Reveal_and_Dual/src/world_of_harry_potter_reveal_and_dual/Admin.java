/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package world_of_harry_potter_reveal_and_dual;

import java.util.*;


/**
 *
 * @author Magical Me
 */
public class Admin {

     String rule1,rule2,rule3,rule4,rule5,rule6,rule7;
     
     Admin(){
         rule1=" 1) Welcome to Reveal & Duel";
         rule2=" 2) This game is a treat for all Potterheads out there :)";
         rule3="3) The game is designed to test your Harry Potter knowledge" ;
         rule4="4) The game offers 2 types of challenges named as Reveal and Duel";
         rule5="5) Reveal - Answer questions to reveal an object";
         rule6=" 6) Duel  - Against Voldemort";
         rule7="7) Good Luck!!!";
     }

    public String getRule1() {
        return rule1;
    }

    public String getRule2() {
        return rule2;
    }

    public String getRule3() {
        return rule3;
    }

    public String getRule4() {
        return rule4;
    }

    public String getRule5() {
        return rule5;
    }

    public String getRule6() {
        return rule6;
    }

    public String getRule7() {
        return rule7;
    }
     
   
}
